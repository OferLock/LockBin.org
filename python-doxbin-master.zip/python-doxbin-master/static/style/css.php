<pre>
<?php
header("Location: /");
?>
</pre>
